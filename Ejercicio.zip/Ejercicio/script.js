// fetch para obtener los municipios del json
fetch('estados-municipios.json')
    .then(response => response.json())
    .then(data => {
        const estadoSelect = document.getElementById('estado');
        const municipioSelect = document.getElementById('municipio');

        // Poblamos el select de estados
        for (const [codigo, municipios] of Object.entries(data)) {
            let option = document.createElement('option');
            option.value = codigo;
            option.textContent = codigo;
            estadoSelect.appendChild(option);
        }

        // Al cambiar el estado, actualizamos los municipios
        estadoSelect.addEventListener('change', function () {
            const estadoSeleccionado = this.value;
            const municipios = data[estadoSeleccionado];

            // Limpiar el select de municipios antes de agregar los nuevos
            municipioSelect.innerHTML = '<option value="">Selecciona un municipio</option>';

            if (municipios) {
                municipios.forEach(municipio => {
                    let option = document.createElement('option');
                    option.value = municipio;
                    option.textContent = municipio;
                    municipioSelect.appendChild(option);
                });
            }
        });
    })
    .catch(error => console.error('Error:', error));  // Manejo de errores

// Manejo del submit del formulario
document.getElementById('formulario').addEventListener('submit', function (event) {
    event.preventDefault();
    const nombre = document.getElementById('nombre').value;
    const estado = document.getElementById('estado').value;
    const municipio = document.getElementById('municipio').value;
    const direccion = document.getElementById('direccion').value;

    alert(`Nombre: ${nombre}\nEstado: ${estado}\nMunicipio: ${municipio}\nDirección: ${direccion}`);
});
